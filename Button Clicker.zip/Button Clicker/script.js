<button onclick="alert('ninja was liked')">likes</button>;
