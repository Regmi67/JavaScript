console.log("I am JS");

var like1 = 3;
var like2 = 9;
var like3 = 12;
var like4 = 9;

function addLike1() {
  var increaseLike1 = document.querySelector("#counting-Like1");
  increaseLike1++;
  increaseLike1.innerText = like1 + like(s);
}
function addLike2() {
  var increaseLike2 = document.querySelector("#counting-Like2");
  increaseLike2++;
  increaseLike2.innerText = like2 + like(s);
}
function addLike3() {
  var increaseLike3 = document.querySelector("#counting-Like3");
  increaseLike3++;
  increaseLike3.innerText = like3 + like(s);
}
function addLike4() {
  var increaseLike4 = document.querySelector("#counting-Like4");
  increaseLike4++;
  increaseLike4.innerText = like4 + like(s);
}
function addLike4()